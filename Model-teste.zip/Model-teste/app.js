const usuarioModel = require("./models/usuario");
const tarefaModel = require("./models/tarefa");
const bd = {
    Digimons: ["Agumon"],
    img: ["https://digimon.shadowsmith.com/img/agumon.jpg"],
    level: ["Rookie"]
}
const express = require("express");
const app = express();

const alvaro = new usuarioModel.Usuario ("Alvaro","alvaro@gmail.com", "1234567890");
const andarDeSkate = new usuarioModel.Usuario ("Andar de skate","Pegar um skate e ir andar na praça","Pendente","02/01/2023")
console.log(alvaro);
console.log(andarDeSkate);

app.get("/", (req, res) => {
    res.send(bd);
})

app.listen(3000, () => {
    console.log("Bem vindo a porta 3000");
})
class tarefa{
    constructor(titulo, descricao, status, dataCriacao){
        this.titulo = titulo;
        this.descricao = descricao;
        this.status = status;
        this.dataCriacao = dataCriacao;
    }
}

module.exports = {tarefa};